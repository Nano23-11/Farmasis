# FarmaGestión Pro — PWA

## Cómo subir la app a internet (gratis) en 5 minutos

### Paso 1 — Crear cuenta en GitHub
1. Ir a **github.com** → crear cuenta gratuita
2. Crear un repositorio nuevo llamado `farmagestion`
3. Subir todos los archivos de esta carpeta

### Paso 2 — Subir a Vercel (hosting gratis)
1. Ir a **vercel.com** → crear cuenta con tu cuenta de GitHub
2. Hacer clic en **"Add New Project"**
3. Seleccionar el repositorio `farmagestion`
4. En configuración poner:
   - Framework: **Create React App**
   - Build command: `npm run build`
   - Output: `build`
5. Hacer clic en **Deploy**
6. En 2 minutos tenés una URL tipo: `farmagestion.vercel.app`

---

## Instalar en el celular como app

### En Android (Chrome)
1. Abrí la URL en Chrome
2. Tocá el menú (⋮) → **"Agregar a pantalla de inicio"**
3. Confirmá → ¡listo! Aparece el ícono como cualquier app

### En iPhone (Safari)
1. Abrí la URL en Safari (no Chrome)
2. Tocá el botón compartir (□↑)
3. Deslizá y tocá **"Agregar a pantalla de inicio"**
4. Confirmá → ¡listo!

---

## Funciones de la app
- 📊 Dashboard con ventas, ganancia y alertas de stock
- 🛒 Pedidos de clientes con descuento automático de stock
- 📦 Pedidos a proveedores con suma automática de stock
- 💊 Lista de productos con precios, costos y ofertas
- 🧾 Historial de ventas con filtros
- 👥 Clientes y deudas
- 🏭 Proveedores y deudas
- 📈 Control de stock con alertas

## Datos guardados
Los datos se guardan en el dispositivo (localStorage).
Para no perderlos, no borres los datos del navegador.

## Alternativa más simple — Netlify Drop
1. Correr `npm run build` en esta carpeta
2. Ir a **app.netlify.com/drop**
3. Arrastrar la carpeta `build` generada
4. ¡Listo! Te da una URL en segundos
